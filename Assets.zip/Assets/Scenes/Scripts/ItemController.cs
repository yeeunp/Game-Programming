using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemController : MonoBehaviour
{
    public float speed= -0.03f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void LateUpdate()
    {   //화면 왼쪽으로 벗어나면 삭제
        transform.Translate(this.speed, 0, 0);
        if(transform.position.x < -10.0f)
        {
            Destroy(gameObject);
        }
    }

    // 장애물이나 땅과 겹쳐나오지 않게 충돌 시 삭제
    void OnCollisionEnter2D(Collision2D other)
    {
            Destroy(gameObject);  
            Debug.Log("아이템충돌");
    }
}
