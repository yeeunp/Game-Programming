using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleController : MonoBehaviour
{
    public float speed= -0.03f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {//화면 벗어나면 삭제
        transform.Translate(this.speed, 0, 0);
        if(transform.position.x < -10.0f)
        {
            Destroy(gameObject);
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
            Destroy(gameObject);  
            Debug.Log("충돌");
    }
}