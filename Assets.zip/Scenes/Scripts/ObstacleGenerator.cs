using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleGenerator : MonoBehaviour
{
    public GameObject RockPrefab;
    public GameObject BombPrefab;
    public GameObject KnifePrefab;


    float span= 5.0f; //초
    float delta= 0;
    float speed= -0.03f;
    // public float seed=0;
    GameObject item;
    GameObject rock;

    //난이도 조절
    // public void SetParameter(float span, float speed, int ratio)
    // {
    //     this.span= span;
    //     this.speed= speed;
    //     this.ratio= ratio;
    // }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.delta += Time.deltaTime;
        if(this. delta> this.span)
        {
            this.delta= 0;
            // seed= Time.time;
            // Random.InitState((int)seed);
            int dice= Random.Range(1,11); 
            if(dice<=3)         //랜덤으로 장애물 생성
            {
                item= Instantiate(BombPrefab) as GameObject;
            }
            else if(3<dice && dice<= 6)
            {
                item= Instantiate(KnifePrefab) as GameObject;
            }
            else
            {
                item= Instantiate(RockPrefab) as GameObject;
            }
            
            float y= Random.Range(-3,0);    //화면 밑 부분에 배치

            if(item.CompareTag("rock"))     //돌은 바닥에 붙어서만 나오도록
            {
                item.transform.position= new Vector3(10,-4,0);
            }
            else
            {
                item.transform.position= new Vector3(10,y,0);
            }
        
            
            item.GetComponent<ObstacleController>().speed= this.speed;
        }
    }
}
