using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rigid2D;
    Animator animator;
    // float speed = 680.0f;
    float jumpForce = 4.5f;
    // float rollForce = 6.0f;
    // int m_facingDirection = 1;
    

    // Start is called before the first frame update
    void Start()
    {
        this.rigid2D = GetComponent<Rigidbody2D>();
        this.animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {   
        // int key = 0;
        // if(Input.GetKeyDown(KeyCode.LeftArrow)) key = -1;
        // if(Input.GetKeyDown(KeyCode.RightArrow)) key = 1;
        // Debug.Log(key);
        // this.rigid2D.AddForce(transform.right * key * this.speed);
        if (Input.GetKeyDown("space") && this.rigid2D.velocity.y == 0)
        {
            this.animator.SetTrigger("JumpTrigger");
            this.rigid2D.velocity = new Vector2(this.rigid2D.velocity.x, this.jumpForce);
        }
        else if(Input.GetKeyDown("left shift") && this.rigid2D.velocity.y == 0)
        {

            this.animator.SetTrigger("RollTrigger");
            // this.rigid2D.velocity = new Vector2(this.m_facingDirection * this.rollForce,this.rigid2D.velocity.y);
        }
        else if(Input.GetKeyDown("right shift"))
        {   
            Debug.Log("눌림");
            this.animator.SetInteger("AllTrigger",3);

        }

        // this.animator.speed = Mathf.Abs(this.rigid2D.velocity.x)/2.0f;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "rock")
        {
            Debug.Log("rock");
        }
        else if(other.gameObject.tag == "knife")
        {
            Debug.Log("knife");
        }
        else if(other.gameObject.tag == "potion")
        {
            Debug.Log("potion");
            
        }
        else if(other.gameObject.tag == "heart")
        {
            Debug.Log("heart");
            
        }
        else if(other.gameObject.tag == "big")
        {
            Debug.Log("big");
            
        }
        else if(other.gameObject.tag == "ice" | other.gameObject.tag == "bomb")
        {
            Debug.Log("bossItem");
            
        }

    }
}
