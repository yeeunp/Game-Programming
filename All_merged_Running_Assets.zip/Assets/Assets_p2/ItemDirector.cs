using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ItemDirector : MonoBehaviour
{
    // 바꿀 이미지
    public Sprite Lightening;
    public Sprite Ice;

    // 슬롯
    GameObject Item1;
    GameObject Item2;
    int last_used;

    // Start is called before the first frame update
    void Start()
    {
        this.Item1 = GameObject.Find("ItemImage1");
        this.Item2 = GameObject.Find("ItemImage2");
        this.last_used = 1;

        // 나중에 지울 것
        this.Item1.GetComponent<Image>().sprite = Lightening;
        this.Item2.GetComponent<Image>().sprite = Lightening;
    }

    // Update is called once per frame
    void Update()
    {

    }

    void Awake()
    {
        DontDestroyOnLoad(gameObject);
        DontDestroyOnLoad(Item1);
        DontDestroyOnLoad(Item2);

    }
    // https://maeum123.tistory.com/141(이미지 변경)
    // https://learnandcreate.tistory.com/750(아이템 class->json)
    public void storeItem(GameObject other){

        if(this.last_used == 1)
        {
            Debug.Log("2번 써라");
            if(other.tag == "Lightening") this.Item2.GetComponent<Image>().sprite = Lightening;
            else this.Item2.GetComponent<Image>().sprite = Ice;
            this.last_used = 2;
        }
        else
        {
            Debug.Log("1번 써라");
            if(other.tag == "Lightening") this.Item1.GetComponent<Image>().sprite = Lightening;
            else this.Item1.GetComponent<Image>().sprite = Ice;
            this.last_used = 1;
        }
    }
}
