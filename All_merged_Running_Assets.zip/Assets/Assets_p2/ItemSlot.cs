using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemSlot : MonoBehaviour
{
    // // private으로 사용하고 싶지만 inspector창에 표시하고 싶을 때
    // [SerializeField] private Slot[] itemSlots; //아이템슬롯(2개)
    // [SerializeField] private Transform tf_parent; //아이템슬롯의 부모 오브젝트

    // private int selectedSlot; //선택된 아이템슬롯 인덱스(0~1)
    // [SerializeField] private GameObject go_SelectedImage; //선택된 퀵슬롯 이미지

    // [SerializeField]
    // private We
    

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
