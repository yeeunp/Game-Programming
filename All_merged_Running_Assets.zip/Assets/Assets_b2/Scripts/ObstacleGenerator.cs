using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleGenerator : MonoBehaviour
{
    public GameObject RockPrefab;
    public GameObject BombPrefab;
    public GameObject KnifePrefab;


    float span= 5.0f; //초
    float delta= 0;
    float speed= -0.03f;

    [Header("Difficulty")]
    public float minSpawnDelay;
    public float maxSpawnDelay;

    // public float seed=0;
    //GameObject item;
    //GameObject rock;

    //난이도 조절
    // public void SetParameter(float span, float speed, int ratio)
    // {
    //     this.span= span;
    //     this.speed= speed;
    //     this.ratio= ratio;
    // }

    // Start is called before the first frame update
    void Start()
    {
        span = Random.Range(minSpawnDelay, maxSpawnDelay);
    }

    // Update is called once per frame
    void Update()
    {
        this.delta += Time.deltaTime;
        if(this. delta> this.span)
        {
            this.delta= 0;
            span = Random.Range(minSpawnDelay, maxSpawnDelay);

            int tryCount = 0;
            while(!Spawn() && tryCount < 3)
                tryCount++;
        }
    }

    bool Spawn()
    {
        var item = SpawnItem();
        var itemColliders = GetItemColliders(item);

        foreach(var collider in itemColliders)
        {
            List<Collider2D> overlapColliders = new List<Collider2D>();
            var overlapCount = Physics2D.OverlapCollider(collider, new ContactFilter2D(), overlapColliders);
            overlapColliders.RemoveAll(e => itemColliders.Contains(e));

            if(overlapColliders.Count > 0)
            {
                Destroy(item);
                return false;
            }
        }

        return true;
    }

    List<Collider2D> GetItemColliders(GameObject item)
    {
        List<Collider2D> colliders = new List<Collider2D>();
        colliders.AddRange(item.GetComponentsInChildren<Collider2D>());

        return colliders;
    }

    GameObject SpawnItem()
    {
        GameObject item;

        int dice = Random.Range(1, 11);

        if(dice <= 3)         //랜덤으로 장애물 생성
        {
            item = Instantiate(BombPrefab) as GameObject;
        }
        else if(3 < dice && dice <= 6)
        {
            item = Instantiate(KnifePrefab) as GameObject;
        }
        else
        {
            item = Instantiate(RockPrefab) as GameObject;
        }

        float y = Random.Range(-3, 0);    //화면 밑 부분에 배치

        if(item.CompareTag("rock"))     //돌은 바닥에 붙어서만 나오도록
        {
            item.transform.position = new Vector3(10, -4, 0);
        }
        else
        {
            item.transform.position = new Vector3(10, y, 0);
        }


        item.GetComponent<ObstacleController>().speed = this.speed;

        Physics2D.SyncTransforms();

        return item;
    }
}
