using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rigid2D;
    Animator animator;
    float jumpForce = 7.5f;

    // 슬롯
    GameObject itemDirector;
    // 시간 UI
    GameObject timeBar;    

    // Start is called before the first frame update
    void Start()
    {
        this.rigid2D = GetComponent<Rigidbody2D>();
        this.animator = GetComponent<Animator>();

        this.itemDirector = GameObject.Find("ItemDirector");
        // this.timeBar = GetObject.Find("TimeBar");
    }

    // Update is called once per frame
    void Update()
    {   
        if(gameObject.transform.position.y < -5)
        {
            Debug.Log("Die!!!!!!");
            Destroy(gameObject);
        }
        // int key = 0;
        // if(Input.GetKeyDown(KeyCode.LeftArrow)) key = -1;
        // if(Input.GetKeyDown(KeyCode.RightArrow)) key = 1;
        // Debug.Log(key);
        // this.rigid2D.AddForce(transform.right * key * this.speed);
        if (Input.GetKeyDown("space") && this.rigid2D.velocity.y == 0)
        {
            this.animator.SetTrigger("JumpTrigger");
            this.rigid2D.velocity = new Vector2(this.rigid2D.velocity.x, this.jumpForce);
        }
        else if(Input.GetKeyDown("left shift") && this.rigid2D.velocity.y == 0)
        {
            this.animator.SetTrigger("RollTrigger");
            // this.rigid2D.velocity = new Vector2(this.m_facingDirection * this.rollForce,this.rigid2D.velocity.y);
        }


        // this.animator.speed = Mathf.Abs(this.rigid2D.velocity.x)/2.0f;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "rock" | other.gameObject.tag == "knife" | other.gameObject.tag == "vine")
        {   
            // 공격받을 때마다 10%씩 닳는 함수
            float power = 0.1f;
            // timeBar.GetComponent<TimebarController>().decreaseTime(power);
            Debug.Log("Obstacle");
            Destroy(other.gameObject);
        }
        else if(other.gameObject.tag == "potion")
        {
            // potion 먹을 때마다 50% 회복하는 함수
            float recovery = 0.5f;
            // timeBar.GetComponent<TimebarController>().increaseTime(power);
            Debug.Log("potion");
            Destroy(other.gameObject);
        }
        else if(other.gameObject.tag == "heart")
        {
            // potion 먹을 때마다 100% 회복하는 함수
            // float recovery = 1.9f;
            // timeBar.GetComponent<TimebarController>().increaseTime(power);
            Debug.Log("heart");
            Destroy(other.gameObject);
            
        }
        else if(other.gameObject.tag == "big")
        {
            
            Debug.Log("big");
            Destroy(other.gameObject);
            
        }
        else if(other.gameObject.tag == "ice" | other.gameObject.tag == "bomb")
        {   
            // item종류가 ice나 bomb인 경우 slot에 저장
            Debug.Log("It's Item for boss");
            itemDirector.GetComponent<ItemDirector>().storeItem(other.gameObject);
            Destroy(other.gameObject);
            
        }
        

    }
}
