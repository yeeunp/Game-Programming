using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossPlayerController : MonoBehaviour
{
    Rigidbody2D rigid2D;
    Animator animator;
    // float speed = 7.5f;
    // float jumpForce = 4.5f;
    // int m_facingDirection = 1;

    // Start is called before the first frame update
    void Start()
    {
        this.rigid2D = GetComponent<Rigidbody2D>();
        this.animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
