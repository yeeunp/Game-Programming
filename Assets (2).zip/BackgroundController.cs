using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundController : MonoBehaviour
{
    // 프리팹으로 속도 변수 제어
    public float speed;
    public GameObject[] backgrounds;

    // Vector3[] startPos;
    public int CameraWidth;
    // Start is called before the first frame update
    void Start()
    {
        // startPos0 = backgrounds[0].position;
        // startPos1 = backgrounds[1].position;
        // backgrounds[1].localScale = new Vector2(-1, 0);
        // Debug.Log(backgrounds.Length);
        // for(int i = 0; i < backgrounds.Length ; i++)
        // {
        //     Debug.Log(backgrounds[i].transform.position.ToString());
        //     // startPos[i] = backgrounds[i].transform.position;
        // }

    }

    // Update is called once per frame
    void Update()
    {
        for(int i = 0; i < backgrounds.Length; i++)
        {
            backgrounds[i].transform.position += new Vector3(-speed, 0, 0) * Time.deltaTime;
            // if(backgrounds[i].transform.position.x + backgrounds[i].GetComponent<RectTransform>().rect.width/2 < CameraWidth)
            if(backgrounds[i].transform.position.x+speed+backgrounds[1].GetComponent<RectTransform>().rect.width < CameraWidth )
            {
                float newX = 0;
                if(i == 0)
                {
                    newX = backgrounds[1].transform.position.x + backgrounds[1].GetComponent<RectTransform>().rect.width*4;
                }
                else if(i==1) 
                {
                    newX = backgrounds[0].transform.position.x + backgrounds[0].GetComponent<RectTransform>().rect.width*4;
                }
                backgrounds[i].transform.position = new Vector3(newX-0.2f,backgrounds[i].transform.position.y,backgrounds[i].transform.position.z);
            }
        }
    }
}
