using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemGenerator : MonoBehaviour
{
    public GameObject BombPrefab;
    public GameObject HeartPrefab;
    public GameObject IcePrefab;
    public GameObject PotionPrefab;

    float span= 5.0f;
    float delta= 0;
    int ratio= 2;
    float speed= -0.03f;
    public float seed=0;

    // public void SetParameter(float span, float speed, int ratio)
    // {
    //     this.span= span;
    //     this.speed= speed;
    //     this.ratio= ratio;
    // }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.delta += Time.deltaTime;
        if(this. delta> this.span)
        {
            this.delta= 0;
            GameObject item;
            seed= Time.time;
            Random.InitState((int)seed);
            int dice= Random.Range(1,11);
            if(dice<=this.ratio)
            {
                item= Instantiate(BombPrefab) as GameObject;
            }
            else
            {
                item= Instantiate(HeartPrefab) as GameObject;
            }
            

            float y= Random.Range(-4,4); //-1,0,1
            
            item.transform.position= new Vector3(10,y,0);
            item.GetComponent<ItemController>().speed= this.speed;
        }
    }
}
